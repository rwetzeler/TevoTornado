                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


https://www.thingiverse.com/thing:2667735
Tevo Tornado BLTouch Mount Updated by dfmsguitar is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

I updated the BLTouch mount that I originally created for the Tevo Tornado. 

A couple of beneftis:
* The wire routing hole is made to fit the dupont connectors without having to remove the wires
* There's a hole that will let you access the screw for the X carriage wheel without having to take off the mount.
* The mount fits a lot better now
* The distance from the nozzle to the tip of the BLTouch is the same, so no need to change the firmware.
* Also updated to add a hole so you can adjust the calibration screw on top of the BLTouch itself. - I'll leave both versions, but you'll probably want to print this one.

Installation instructions video below:
https://www.youtube.com/watch?v=mBwHGuX5de8

Thanks to thisiskeithb for the suggestions.